extends Control

@onready var playButton = $VBoxContainer/PlayButton
@onready var namePanel = $VBoxContainer/NamePanel
@onready var nameInput = $VBoxContainer/NamePanel/NameInput
@onready var errorLabel = $VBoxContainer/NamePanel/ErrorLabel

var skipButton: Button
var level3Button: Button

const LEVEL3_SCENE := "res://scenes/Nivel_3/1Entrada del Laboratorio.tscn"

func _ready():
	_applyGlobalTheme()
	_createSkipButton()
	_createLevel3Button()
	# ── Música del menú principal ──────────────────────────────────────────
	DJManager.playMusic("menu")

func _applyGlobalTheme() -> void:
	var font = load("res://assets/fonts/MotionControl-Bold.otf")
	var globalTheme = Theme.new()
	globalTheme.default_font = font
	globalTheme.default_font_size = 20
	get_tree().root.theme = globalTheme

func _createSkipButton() -> void:
	skipButton = Button.new()
	skipButton.text = "Omitir intro"
	skipButton.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	skipButton.custom_minimum_size = Vector2(200, 40)
	skipButton.add_theme_font_size_override("font_size", 16)
	skipButton.add_theme_color_override("font_color", Color(0.6, 0.6, 0.6))
	skipButton.pressed.connect(_on_skip_button_pressed)
	$VBoxContainer.add_child(skipButton)

# Boton para saltar directo al nivel 3
func _createLevel3Button() -> void:
	level3Button = Button.new()
	level3Button.text = "Saltar a nivel 3"
	level3Button.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	level3Button.custom_minimum_size = Vector2(200, 40)
	level3Button.add_theme_font_size_override("font_size", 16)
	level3Button.add_theme_color_override("font_color", Color(0.6, 0.6, 0.6))
	level3Button.pressed.connect(_on_level3_button_pressed)
	$VBoxContainer.add_child(level3Button)

func _on_play_button_pressed() -> void:
	playButton.visible = false
	skipButton.visible = false
	level3Button.visible = false
	namePanel.visible = true
	nameInput.grab_focus()

func _on_confirm_button_pressed() -> void:
	var nombre = nameInput.text.strip_edges()
	if nombre.length() < 3:
		errorLabel.text = "El nombre debe tener al menos 3 caracteres."
		errorLabel.visible = true
		return
	errorLabel.visible = false
	GameData.playerName = nombre
	get_tree().change_scene_to_file("res://scenes/nivel_0/Intro.tscn")

func _on_skip_button_pressed() -> void:
	GameData.playerName = "Player"
	get_tree().change_scene_to_file("res://scenes/nivel_1/Main.tscn")

func _on_level3_button_pressed() -> void:
	GameData.playerName = "Player"
	get_tree().change_scene_to_file(LEVEL3_SCENE)
